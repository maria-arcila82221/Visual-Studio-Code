
ScrollReveal().reveal('.reveal',{delay: 500});